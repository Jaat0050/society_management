<div>
    <div class="mb-6 overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-600 to-cyan-500 p-6 text-white shadow-lg">
        <h3 class="text-2xl font-bold">Society Analytics Dashboard</h3>
        <p class="text-indigo-100 text-sm mt-1"><?php echo e(auth()->user()->society?->name); ?> — real-time overview</p>
    </div>

    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div class="form-card !p-4 border-l-4 border-l-emerald-500">
            <p class="text-xs text-slate-500">Occupancy</p>
            <p class="text-2xl font-bold"><?php echo e($stats['occupancy']); ?>% <span class="text-sm font-normal text-slate-500">/ <?php echo e($stats['flats']); ?> flats</span></p>
        </div>
        <div class="form-card !p-4 border-l-4 border-l-indigo-500">
            <p class="text-xs text-slate-500">Residents</p>
            <p class="text-2xl font-bold"><?php echo e($stats['residents']); ?></p>
        </div>
        <div class="form-card !p-4 border-l-4 border-l-amber-500">
            <p class="text-xs text-slate-500">Pending Dues</p>
            <p class="text-2xl font-bold text-amber-600">₹<?php echo e(number_format($stats['pending_dues'],0)); ?></p>
            <p class="text-xs text-slate-400"><?php echo e($stats['pending_bills']); ?> bills</p>
        </div>
        <div class="form-card !p-4 border-l-4 border-l-emerald-600">
            <p class="text-xs text-slate-500">Collected (all time)</p>
            <p class="text-2xl font-bold text-emerald-600">₹<?php echo e(number_format($stats['collected'],0)); ?></p>
        </div>
        <div class="form-card !p-4"><p class="text-xs text-slate-500">Open Complaints</p><p class="text-2xl font-bold text-red-600"><?php echo e($stats['open_complaints']); ?></p></div>
        <div class="form-card !p-4"><p class="text-xs text-slate-500">Visitors Inside</p><p class="text-2xl font-bold text-indigo-600"><?php echo e($stats['visitors_inside']); ?></p></div>
        <div class="form-card !p-4"><p class="text-xs text-slate-500">Pending Approvals</p><p class="text-2xl font-bold"><?php echo e($stats['visitors_pending']); ?></p></div>
        <div class="form-card !p-4"><p class="text-xs text-slate-500">Expenses (this month)</p><p class="text-2xl font-bold text-red-600">₹<?php echo e(number_format($stats['expenses_month'],0)); ?></p></div>
    </div>

    <div class="grid lg:grid-cols-2 gap-6 mb-6">
        <div class="form-card">
            <h3 class="font-semibold mb-1">Maintenance Collection</h3>
            <p class="text-xs text-slate-500 mb-4">Last 6 months</p>
            <div class="h-72"><canvas id="chart-admin-collection" wire:ignore></canvas></div>
        </div>
        <div class="form-card">
            <h3 class="font-semibold mb-1">Daily Visitor Entries</h3>
            <p class="text-xs text-slate-500 mb-4">Last 7 days at gate</p>
            <div class="h-72"><canvas id="chart-admin-visitors" wire:ignore></canvas></div>
        </div>
        <div class="form-card">
            <h3 class="font-semibold mb-1">Bills by Status</h3>
            <div class="h-64 flex items-center justify-center"><canvas id="chart-admin-bills" wire:ignore></canvas></div>
        </div>
        <div class="form-card">
            <h3 class="font-semibold mb-1">Complaints Breakdown</h3>
            <div class="h-64"><canvas id="chart-admin-complaints" wire:ignore></canvas></div>
        </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(collect($chartConfigs)->contains(fn($c) => ($c['id'] ?? '') === 'chart-admin-expenses')): ?>
        <div class="form-card lg:col-span-2">
            <h3 class="font-semibold mb-1">Expenses by Category</h3>
            <p class="text-xs text-slate-500 mb-4">Last 3 months</p>
            <div class="h-64 max-w-lg mx-auto"><canvas id="chart-admin-expenses" wire:ignore></canvas></div>
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <div class="grid md:grid-cols-2 gap-6">
        <div class="form-card">
            <div class="flex justify-between items-center mb-3">
                <h3 class="font-semibold">Recent Complaints</h3>
                <a href="<?php echo e(route('admin.reports')); ?>" wire:navigate class="text-xs text-indigo-600 font-semibold">Full reports →</a>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $recentComplaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="text-sm py-2 border-b"><p class="font-medium"><?php echo e($c->subject); ?></p><p class="text-xs text-slate-500"><?php echo e($c->flat?->label); ?> · <?php echo e($c->status); ?></p></div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
        <div class="form-card">
            <h3 class="font-semibold mb-3">Quick Links</h3>
            <div class="grid grid-cols-2 gap-2 text-sm">
                <a href="<?php echo e(route('admin.billing')); ?>" wire:navigate class="rounded-lg bg-slate-50 px-3 py-2 hover:bg-indigo-50">💰 Billing</a>
                <a href="<?php echo e(route('admin.visitors')); ?>" wire:navigate class="rounded-lg bg-slate-50 px-3 py-2 hover:bg-indigo-50">🚪 Visitors</a>
                <a href="<?php echo e(route('admin.accounting')); ?>" wire:navigate class="rounded-lg bg-slate-50 px-3 py-2 hover:bg-indigo-50">📒 Accounting</a>
                <a href="<?php echo e(route('admin.complaints')); ?>" wire:navigate class="rounded-lg bg-slate-50 px-3 py-2 hover:bg-indigo-50">📋 Complaints</a>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <?php echo $__env->make('partials.chart-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script type="application/json" data-chart-config><?php echo json_encode($chartConfigs, 15, 512) ?></script>
    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH C:\laragon\www\society\resources\views/livewire/admin/dashboard.blade.php ENDPATH**/ ?>