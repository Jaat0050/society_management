<div>
    <?php echo $__env->make('livewire.partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <button type="button" wire:click="$set('showForm', true)" class="btn-primary mb-4">+ Add Delivery Staff</button>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showForm): ?>
    <form wire:submit.prevent="save" class="form-card mb-6 space-y-4">
        <h3 class="font-semibold"><?php echo e($editingId ? 'Edit' : 'New'); ?> Delivery Staff</h3>
        <div class="grid md:grid-cols-2 gap-4">
            <div class="form-field"><label class="form-label field-required">Name</label><input type="text" wire:model="name" class="form-control"></div>
            <div class="form-field"><label class="form-label field-required">Phone</label><input type="tel" wire:model="phone" class="form-control"></div>
            <div class="form-field"><label class="form-label">Company</label><input type="text" wire:model="company" class="form-control" placeholder="Swiggy, Amazon..."></div>
            <div class="form-field"><label class="form-label">Vehicle No</label><input type="text" wire:model="vehicle_no" class="form-control"></div>
            <div class="form-field"><label class="form-label">ID Card</label><input type="text" wire:model="id_card_no" class="form-control"></div>
        </div>
        <label class="flex items-center gap-2 text-sm"><input type="checkbox" wire:model="is_verified" class="rounded"> Verified</label>
        <label class="flex items-center gap-2 text-sm"><input type="checkbox" wire:model="is_active" class="rounded"> Active</label>
        <div class="flex gap-2"><button type="submit" class="btn-primary">Save</button><button type="button" wire:click="cancelForm" class="btn-secondary">Cancel</button></div>
    </form>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <div class="form-card">
        <table class="w-full text-sm">
            <thead><tr class="border-b text-left text-slate-500"><th class="py-2">Name</th><th>Company</th><th>Phone</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <tr class="border-b"><td class="py-3 font-medium"><?php echo e($s->name); ?></td><td><?php echo e($s->company); ?></td><td><?php echo e($s->phone); ?></td>
                    <td><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($s->is_verified): ?><span class="text-emerald-600 text-xs">Verified</span><?php else: ?><span class="text-slate-400 text-xs">—</span><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></td>
                    <td class="text-right"><button wire:click="edit(<?php echo e($s->id); ?>)" class="text-indigo-600 text-xs mr-2">Edit</button><button wire:click="delete(<?php echo e($s->id); ?>)" wire:confirm="Remove?" class="text-red-600 text-xs">Delete</button></td>
                </tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH C:\laragon\www\society\resources\views/livewire/admin/delivery-staff.blade.php ENDPATH**/ ?>