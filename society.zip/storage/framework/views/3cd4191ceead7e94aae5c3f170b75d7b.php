<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title ?? 'Dashboard'); ?> — <?php echo e(config('app.name')); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <?php echo $__env->make('partials.form-styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="min-h-screen bg-slate-100 text-slate-800">
    <div class="flex min-h-screen">
        <aside class="w-72 bg-slate-950 text-white flex flex-col shrink-0 shadow-2xl">
            <div class="relative overflow-hidden p-6 border-b border-white/10">
                <div class="absolute -top-10 -right-10 h-32 w-32 rounded-full bg-indigo-500/30 blur-2xl"></div>
                <div class="absolute -bottom-12 -left-10 h-32 w-32 rounded-full bg-cyan-400/20 blur-2xl"></div>
                <div class="relative">
                    <div class="h-11 w-11 rounded-2xl bg-gradient-to-br from-indigo-500 to-cyan-400 flex items-center justify-center font-black shadow-lg">
                        SM
                    </div>
                    <p class="text-xs uppercase tracking-[0.25em] text-cyan-200 mt-4"><?php echo e($panelLabel ?? 'Panel'); ?></p>
                    <h1 class="font-bold text-xl mt-1"><?php echo e(config('app.name')); ?></h1>
                </div>
            </div>
            <nav class="flex-1 p-4 space-y-1 overflow-y-auto">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <a href="<?php echo e(route($item['route'])); ?>" wire:navigate
                       class="group flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition <?php echo e(request()->routeIs($item['route'].'*') ? 'bg-white text-slate-950 shadow-lg shadow-indigo-950/20' : 'text-slate-300 hover:bg-white/10 hover:text-white'); ?>">
                        <span class="grid h-8 w-8 place-items-center rounded-lg <?php echo e(request()->routeIs($item['route'].'*') ? 'bg-indigo-50' : 'bg-white/5 group-hover:bg-white/10'); ?>"><?php echo e($item['icon'] ?? '•'); ?></span>
                        <span class="font-medium"><?php echo e($item['label']); ?></span>
                    </a>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </nav>
            <div class="p-4 border-t border-white/10">
                <div class="rounded-2xl bg-white/5 p-4">
                    <p class="text-sm font-semibold text-white truncate"><?php echo e(auth()->user()->name); ?></p>
                    <p class="text-xs text-slate-400 truncate mt-1"><?php echo e(auth()->user()->email); ?></p>
                </div>
                <form method="POST" action="<?php echo e(route('logout')); ?>" class="mt-3">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="w-full rounded-xl border border-red-400/30 px-3 py-2 text-xs font-semibold text-red-300 hover:bg-red-500/10">Logout</button>
                </form>
            </div>
        </aside>
        <main class="flex-1 overflow-auto">
            <header class="sticky top-0 z-10 border-b border-white/70 bg-white/80 px-8 py-5 backdrop-blur">
                <div class="flex flex-wrap items-center justify-between gap-3">
                    <div>
                        <p class="text-xs font-semibold uppercase tracking-[0.2em] text-indigo-500">Management Console</p>
                        <h2 class="text-2xl font-bold text-slate-900"><?php echo e($header ?? 'Dashboard'); ?></h2>
                    </div>
                    <div class="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm text-slate-500 shadow-sm">
                        <?php echo e(now()->format('d M Y')); ?>

                    </div>
                </div>
            </header>
            <div class="p-8">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
                    <div class="mb-5 rounded-2xl border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-800 shadow-sm"><?php echo e(session('success')); ?></div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
                    <div class="mb-5 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800 shadow-sm"><?php echo e(session('error')); ?></div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php echo e($slot); ?>

            </div>
        </main>
    </div>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
    <div wire:loading.flex wire:target="save,delete,toggleBlock,edit,create,saveAmenity,publish,send,generateBulk,markPaid,updateStatus,updateBookingStatus,toggleActive,authenticate"
         class="fixed inset-0 z-50 hidden items-center justify-center bg-slate-900/20 backdrop-blur-sm">
        <div class="rounded-xl bg-white px-6 py-4 shadow-xl text-sm font-medium text-slate-700">Please wait...</div>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\society\resources\views/layouts/panel.blade.php ENDPATH**/ ?>