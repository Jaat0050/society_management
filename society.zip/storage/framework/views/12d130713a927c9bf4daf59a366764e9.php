<div>
    <?php echo $__env->make('livewire.partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="grid grid-cols-3 gap-4 mb-6">
        <div class="form-card !p-4"><p class="text-xs text-slate-500">Pending</p><p class="text-2xl font-bold text-amber-600"><?php echo e($stats['pending']); ?></p></div>
        <div class="form-card !p-4"><p class="text-xs text-slate-500">Inside</p><p class="text-2xl font-bold text-emerald-600"><?php echo e($stats['inside']); ?></p></div>
        <div class="form-card !p-4"><p class="text-xs text-slate-500">Today</p><p class="text-2xl font-bold"><?php echo e($stats['today']); ?></p></div>
    </div>
    <select wire:model.live="filter" class="form-select mb-4 max-w-xs">
        <option value="all">All statuses</option>
        <option value="pending">Pending</option><option value="approved">Approved</option>
        <option value="checked_in">Checked In</option><option value="checked_out">Checked Out</option>
        <option value="rejected">Rejected</option>
    </select>
    <div class="form-card overflow-x-auto">
        <table class="w-full text-sm">
            <thead><tr class="border-b text-left text-slate-500"><th class="py-2">Visitor</th><th>Flat</th><th>Type</th><th>Pass</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <tr class="border-b border-slate-100">
                    <td class="py-3 font-medium"><?php echo e($e->visitor_name); ?><br><span class="text-xs text-slate-400"><?php echo e($e->phone); ?></span></td>
                    <td><?php echo e($e->flat?->label ?? '—'); ?></td>
                    <td><?php echo e($e->visit_type); ?></td>
                    <td class="font-mono text-xs"><?php echo e($e->pass_code); ?></td>
                    <td><span class="px-2 py-0.5 rounded text-xs bg-slate-100"><?php echo e($e->status); ?></span></td>
                    <td class="text-right space-x-1">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($e->status === 'pending'): ?>
                            <button type="button" wire:click="approve(<?php echo e($e->id); ?>)" class="text-emerald-600 text-xs font-semibold">Approve</button>
                            <button type="button" wire:click="reject(<?php echo e($e->id); ?>)" class="text-red-600 text-xs font-semibold">Reject</button>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($e->status === 'checked_in'): ?>
                            <button type="button" wire:click="checkOut(<?php echo e($e->id); ?>)" class="text-amber-600 text-xs font-semibold">Exit</button>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <a href="<?php echo e(route('visit.qr', $e->qr_token)); ?>" target="_blank" class="text-indigo-600 text-xs">QR</a>
                    </td>
                </tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </tbody>
        </table>
        <div class="mt-4"><?php echo e($entries->links()); ?></div>
    </div>
</div>
<?php /**PATH C:\laragon\www\society\resources\views/livewire/admin/visitors.blade.php ENDPATH**/ ?>