<div>
    <div class="flex flex-wrap gap-3 mb-6 items-center">
        <input type="month" wire:model.live="period" class="form-select max-w-xs">
        <a href="<?php echo e(route('admin.export.ledger')); ?>" class="btn-secondary text-sm">Export CSV</a>
        <a href="<?php echo e(route('admin.export.bills')); ?>" class="btn-secondary text-sm">Export Bills</a>
    </div>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div class="form-card !p-4"><p class="text-xs text-slate-500">Income</p><p class="text-xl font-bold text-emerald-600">₹<?php echo e(number_format($income,0)); ?></p></div>
        <div class="form-card !p-4"><p class="text-xs text-slate-500">Expenses</p><p class="text-xl font-bold text-red-600">₹<?php echo e(number_format($expense,0)); ?></p></div>
        <div class="form-card !p-4"><p class="text-xs text-slate-500">Balance</p><p class="text-xl font-bold">₹<?php echo e(number_format($balance,0)); ?></p></div>
        <div class="form-card !p-4"><p class="text-xs text-slate-500">Pending Dues</p><p class="text-xl font-bold text-amber-600">₹<?php echo e(number_format($pending,0)); ?></p></div>
    </div>
    <div class="grid md:grid-cols-2 gap-6">
        <div class="form-card"><h3 class="font-semibold mb-3">By Category</h3>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $byCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><p class="text-sm py-1 flex justify-between"><span><?php echo e($c->type); ?> / <?php echo e($c->category); ?></span><span>₹<?php echo e(number_format($c->total,0)); ?></span></p><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
        <div class="form-card"><h3 class="font-semibold mb-3">Recent Ledger</h3>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $ledger; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><p class="text-sm py-1 border-b flex justify-between"><span><?php echo e($l->entry_date->format('d M')); ?> <?php echo e($l->description); ?></span><span class="<?php echo e($l->type==='income'?'text-emerald-600':'text-red-600'); ?>">₹<?php echo e(number_format($l->amount,0)); ?></span></p><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\society\resources\views/livewire/admin/accounting.blade.php ENDPATH**/ ?>