<div>
    <?php echo $__env->make('livewire.partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <button wire:click="$set('showForm', true)" class="btn-primary mb-4">+ Add Vendor</button>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showForm): ?>
    <form wire:submit.prevent="save" class="form-card mb-6 space-y-4">
        <div class="grid md:grid-cols-2 gap-4">
            <div class="form-field"><label class="form-label">Name</label><input wire:model="name" class="form-control"></div>
            <div class="form-field"><label class="form-label">Company</label><input wire:model="company" class="form-control"></div>
            <div class="form-field"><label class="form-label">Phone</label><input wire:model="phone" class="form-control"></div>
            <div class="form-field"><label class="form-label">Service</label><input wire:model="service_type" class="form-control" placeholder="Plumbing, Lift AMC"></div>
            <div class="form-field"><label class="form-label">Contract Start</label><input type="date" wire:model="contract_start" class="form-control"></div>
            <div class="form-field"><label class="form-label">Contract End</label><input type="date" wire:model="contract_end" class="form-control"></div>
            <div class="form-field"><label class="form-label">Contract Value</label><input type="number" wire:model="contract_value" class="form-control"></div>
        </div>
        <div class="form-field"><label class="form-label">Schedule Notes</label><textarea wire:model="schedule_notes" class="form-control" rows="2"></textarea></div>
        <div class="flex gap-2"><button type="submit" class="btn-primary">Save</button><button type="button" wire:click="cancelForm" class="btn-secondary">Cancel</button></div>
    </form>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <div class="form-card"><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <div class="py-3 border-b flex justify-between"><div><p class="font-medium"><?php echo e($v->name); ?></p><p class="text-xs text-slate-500"><?php echo e($v->service_type); ?> · <?php echo e($v->phone); ?> · Contract till <?php echo e($v->contract_end?->format('d M Y') ?? '—'); ?></p></div>
        <div><button wire:click="edit(<?php echo e($v->id); ?>)" class="text-indigo-600 text-xs mr-2">Edit</button><button wire:click="delete(<?php echo e($v->id); ?>)" wire:confirm class="text-red-600 text-xs">Delete</button></div></div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?></div>
</div>
<?php /**PATH C:\laragon\www\society\resources\views/livewire/admin/vendors.blade.php ENDPATH**/ ?>